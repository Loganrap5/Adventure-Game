﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MidtermAdventureGame
{
    public class Quarry
    {
        //quarry class with different options of survival and food, also adding rockslide method
        //also more access to sun
        public int temperature;

        public bool isRaining;
        bool isWindy;
        bool isThunderstorming;

        public Quarry()
        {
            this.temperature = 75;
            this.isRaining = false;
            this.isWindy = false;
            this.isThunderstorming = false;
        }

        public void Rain()
        {
            isRaining = true;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("It is now raining out!");
            Console.ForegroundColor = ConsoleColor.Gray;

        }




        public void Rockslide()
        {
            //isRaining = true;
            isWindy = true;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Look out! The walls of the quarry seem to be collapsing!");
            Console.WriteLine("It seems the rain has chipped away at the foundation of the rock formations, and slowly they are falling");
            Console.WriteLine("You see the rocks coming your way and you quickly run.");
            
            Console.ForegroundColor = ConsoleColor.Gray;


        }

        public void AboutQuarry()
        {
            Console.ForegroundColor = ConsoleColor.Green;
            if (isRaining == true)
            {
                Console.WriteLine($"It is {temperature} degrees. And it is raining.");

            }

            if (isThunderstorming == true)
            {
                Console.WriteLine($"It is {temperature} degrees. It is now thunderstorming outside!");


            }

            else if (temperature < 70)
            {
                Console.WriteLine($"It is {temperature} degrees. Its slightly chilly!");


            }

            else if (temperature > 71)
            {
                Console.WriteLine($"It is {temperature} degrees. Its a comfortable temperature outside.");



            }
            Console.ForegroundColor = ConsoleColor.Gray;



        }

        public void Thunderstorm()
        {
            isThunderstorming = true;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("It is now thunderstorming, maybe find some shelter?");
            Console.ForegroundColor = ConsoleColor.Gray;



        }

    }
}