﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MidtermAdventureGame
{
    public class Biome
    {
        protected int temperature;
        protected string biomeType;

        protected bool isRaining;
        protected bool isWindy;
        protected bool isThunderstorming;

        public Biome(int _temperature, string _biomeType)
        {
            this.temperature = _temperature;
            this.biomeType = _biomeType;

        }

        public void AboutBiome()
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"You are currently in the {this.biomeType}, currently it is {this.temperature} degrees out.");
            if(isRaining == true)
            {
                Console.WriteLine("It is currently raining out.");
            }
            if(isThunderstorming == true)
            {
                Console.WriteLine("It is currently thunderstorming out.");
            }

            Console.ForegroundColor = ConsoleColor.Gray;

        }

        public void Rain()
        {
            isRaining = true;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("It is now raining.");
            Console.ForegroundColor = ConsoleColor.Gray;



        }

        public void StopRain()
        {
            isRaining = false;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("It is no longer raining.");
            Console.ForegroundColor = ConsoleColor.Gray;
        }

        public void Thunderstorm()
        {
            isThunderstorming = true;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("It is now thunderstorming.");
            Console.ForegroundColor = ConsoleColor.Gray;




        }

        public void Wind()
        {
            isWindy = true;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("It is now windy out.");
            Console.ForegroundColor = ConsoleColor.Gray;

        }

        public void DecreaseTemp()
        {
            temperature = temperature - 10;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"It is colder out in the {biomeType}.");
            Console.ForegroundColor = ConsoleColor.Gray;

        }
        public void IncreaseTemp()
        {
            temperature = temperature + 10;
            Console.ForegroundColor= ConsoleColor.Green;
            Console.WriteLine($"It is warmer out in the {biomeType}.");
            Console.ForegroundColor = ConsoleColor.Gray;

        }


    }
}
    
