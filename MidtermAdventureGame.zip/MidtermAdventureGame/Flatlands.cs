﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace MidtermAdventureGame
{
    public class Flatlands : Biome
    {
        public Flatlands(int _temperature, string _biomeType) : base(_temperature, _biomeType)
        {
            this.isRaining = false;
            this.isWindy = false;
            this.isThunderstorming = false;




        }

        public void AboutFlatLands()
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"Welcome to the {this.biomeType}! This is a very flat wilderness with lots of tall grass. Not much to forage\nand water seems to be hard to find.");
            Console.ForegroundColor = ConsoleColor.Gray;


        }

    }

    
}
