﻿using System;
using System.CodeDom;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http.Headers;
using System.Runtime.InteropServices.ComTypes;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace MidtermAdventureGame
{
    public class Game
    {
        Character myCharacter1 = new Character();
        Wilderness myWilderness1 = new Wilderness();
        Quarry myQuarry1 = new Quarry();
        int userInput;
        int userMenuInput;
        bool running = true;

        //bool for fire being active to cook fish
        bool fireActive;
        
        string narrative1 = "Welcome to the Survival Game. Make it through to the end in order to get rescued!";
        string narrative2 = "You wake up to find yourself alone in the wilderness. Before you there are two paths...";
        string narrative3 = "Type 1 to enter the path on the left, type 2 to goto the right.";
        string narrative4 = "You continue to walk the path on the left for a while, and eventually you see nothing around you but forest.";
        string narrative5 = "You walk a short distance after choosing the path on the right, you are eventually lead\nto a quarry with a big lake in the middle";

        //methods

        //methods for main menu
        public void Play()
        {
            Console.Clear();
            

        }
        public void Credits()
        {
            Console.Clear();
            Console.WriteLine("Adventure game created by Logan Rappaport");
            Console.WriteLine("Press enter to return...");
            Console.ReadLine();
        }
       //add instructions!!!!!!!
        public void Instructions()
        {
            Console.Clear();
            Console.WriteLine("Hello, and welcome to the Survival Adventure Game, you choose your own adventure and try to make it to the end!");
            Console.WriteLine("There are multiple ways to play the game, maybe retry and try and choose all paths?");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Whenever text is in red... it shows updates to your characters statistics.");
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("If text is in green... it is showing the current statistics of the location you are at.");
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine("For thirst and hunger levels, the lower the value (between 1-10), the more hungry/thirsty you are.");
            Console.WriteLine("Press enter to return...");
            Console.ReadLine();

        }
        public void ExitGame()
        {
            Environment.Exit(10);

        }
        
        public void Menu()
        {
            while (running == true)
            {
                Console.Clear();
                Console.WriteLine("Please enter an option from the menu.");
                Console.WriteLine("1) Start game.");
                Console.WriteLine("2) Instructions.");
                Console.WriteLine("3) Credits.");
                Console.WriteLine("4) Exit Game.");

                userMenuInput = Convert.ToInt16(Console.ReadLine());

                switch(userMenuInput)
                {
                    case 1:
                        Play();
                        running = false;
                        break;
                   
                    case 2:
                        Instructions();
                        break;

                    case 3:
                        Credits();
                        break;

                    case 4:
                        ExitGame();
                        break;



                }

            }


        }
              
        public void Intro()
        {
            Console.WriteLine(" _____ __ __  ____  __ __  ____  __ __   ____  _           ____   ____  ___ ___    ___ \r\n / ___/|  |  ||    \\|  |  ||    ||  |  | /    || |         /    | /    ||   |   |  /  _]\r\n(   \\_ |  |  ||  D  )  |  | |  | |  |  ||  o  || |        |   __||  o  || _   _ | /  [_ \r\n \\__  ||  |  ||    /|  |  | |  | |  |  ||     || |___     |  |  ||     ||  \\_/  ||    _]\r\n /  \\ ||  :  ||    \\|  :  | |  | |  :  ||  _  ||     |    |  |_ ||  _  ||   |   ||   [_ \r\n \\    ||     ||  .  \\\\   /  |  |  \\   / |  |  ||     |    |     ||  |  ||   |   ||     |\r\n  \\___| \\__,_||__|\\_| \\_/  |____|  \\_/  |__|__||_____|    |___,_||__|__||___|___||_____|");
               


                
               
            Console.WriteLine("Hello! And welcome to the Survival Adventure Game!");
            Console.WriteLine("Press enter to continue...");
            Console.ReadLine();
            Console.Clear();

            //create name for character after welcoming them
            myCharacter1.CreateName();
            myCharacter1.About();

            Console.WriteLine(narrative1);
            Console.WriteLine("Press enter to continue...");
            Console.ReadLine();
            Console.Clear();

            Console.WriteLine(narrative2);
            Console.WriteLine(narrative3);

            
            userInput = Convert.ToInt16(Console.ReadLine());
            
            if(userInput == 1)
            {
                //wilderness choice
                Console.WriteLine(narrative4);
                Console.WriteLine("Press enter to continue...");
                Console.ReadLine();
                WildernessChoice();
                
                
                

            }
            else if(userInput == 2)
            {
                //quarry choice 
                Quarry myQuarry1 = new Quarry();
                //Console.WriteLine(narrative5);
                //Console.WriteLine("Press enter to continue...");
                //Console.ReadLine();
                QuarryChoice();
                
            }
            userInput = 0;
            Console.ReadLine();
            

        }

        
        //Wilderness Option ------------------------------------------------------------------------------------------------------
        public void WildernessChoice()
        {
            Console.Clear();
            Console.WriteLine("Unfortunatly, you seem to be lost in the forest.");
            Console.WriteLine("You have a couple of options, currently your statistics are... ");
            Console.WriteLine();
            myCharacter1.SimpleAbout();
            Console.WriteLine("Press enter to continue...");
            Console.ReadLine();

            //list options
            Console.WriteLine("You need to choose a place to spend the night. Its getting dark and will eventually be cold out.");
            Console.WriteLine("You look at your options and decide between two places to set up a quick camp.");
            Console.WriteLine("Type 1 to choose the area clear of trees, but closer to the river.");
            Console.WriteLine("Type 2 to go further into the woods, away from the wind.");


            userInput = Convert.ToInt16(Console.ReadLine());
            //first option in wilderness class
            if(userInput ==  1)
            {
                Console.Clear();
                Console.WriteLine("You have decided to make camp close to the river. But you notice its getting chilly out.");
                myCharacter1.MakeCold();
                myWilderness1.DecreaseTemp();
                Console.WriteLine("You should create a campfire in order to warm up!");
                Console.WriteLine("Press enter to continue...");
                Console.ReadLine();


                Console.Clear();

                Console.WriteLine("Unfortunatly since you are near the river you need to go collect firewood.");
                myCharacter1.MakeTired();
                Console.WriteLine("You have got your firewood but you need to get rest. Also walking has made you hungry.");
                myCharacter1.MakeHungry();
                Console.WriteLine("Press enter to continue...");
                Console.ReadLine();

                Console.Clear();
                Console.WriteLine("You have collected your firewood and you can now create your fire.");
                Console.WriteLine("Press enter to create a fire...");
                Console.ReadLine();
                myCharacter1.MakeFire();


                //time to sleep
                Console.WriteLine("You have created fire! You can now get some rest and wake up to find food.");            
                Console.WriteLine("Get some rest now!");
                Console.WriteLine("Press enter to continue...");
                Console.ReadLine();

                Console.Clear();


                myCharacter1.Sleep();
                Console.WriteLine("Good Morning! Here are your current statistics...");
                myCharacter1.thirstLevel = 3;
                myCharacter1.SimpleAbout();
                Console.WriteLine();
                Console.WriteLine("Press enter to continue...");
                Console.ReadLine();

                Console.Clear();

                Console.WriteLine("It is now the beginning of the day and you are able to move on!");
                Console.WriteLine("Here are the current statistics of the wilderness.");
                myWilderness1.temperature = 75;
                myWilderness1.AboutWilderness();
                Console.WriteLine("Press enter to continue...");
                
                running = true;
                Console.ReadLine();

                while (running == true)
                {
                    Console.Clear();
                    Console.WriteLine("Please select a couple options to continue on.");
                    Console.WriteLine("1) Continue Travelling.");
                    Console.WriteLine("2) Drink Water.");
                    Console.WriteLine("3) See Wilderness Stats.");

                    userMenuInput = Convert.ToInt16(Console.ReadLine());

                    switch(userMenuInput)
                    {
                        case 1:
                            if (myCharacter1.thirstLevel < 4)
                            {
                                Console.Clear();
                                Console.WriteLine("You are too thirsty! Go back and drink some water before you travel.");
                                Console.WriteLine("Press enter to go back...");
                                Console.ReadLine();
                                break;
                            }

                            else
                            {
                                WildernessPart2();
                                running = false;
                                break;
                            }
                        case 2:
                            Console.Clear();
                            myCharacter1.thirstLevel = 10;
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("Your thirst level is now 10.");
                            Console.ForegroundColor = ConsoleColor.Gray;
                            Console.ReadLine();
                            break;
                        case 3:
                            Console.Clear();
                            myWilderness1.AboutWilderness();
                            Console.ReadLine();
                            break;

                            
                           



                    }



                }



            }
            //second option in wilderness class
            else if(userInput == 2)
            {
                Console.Clear();
                Console.WriteLine("You decided to make camp farther into the forest, it is now dark outside.");
                myWilderness1.DecreaseTemp();
                Console.WriteLine("You have been walking for a while now, and notice some small berries on some bushes along the way.");
                Console.WriteLine("You are not very hungry yet, but not quite full. Press enter to Scavenge some berries.");
                Console.ReadLine();
                myCharacter1.Scavenge();
                Console.WriteLine("Press enter to continue...");
                Console.ReadLine();

                Console.Clear();

                Console.WriteLine("You are deep in the forest, and will soon need to find a place to spend the night.");
                Console.WriteLine("The current stats for the wilderness are...");
                myWilderness1.AboutWilderness();
                myCharacter1.MakeCold();
                Console.WriteLine();
                Console.WriteLine("You have been walking for a while now, and its very dark out. You are also starting to lose more energy by continuing to walk.");
                myCharacter1.weight = myCharacter1.weight - 2;
                myCharacter1.MakeTired();
                Console.WriteLine("Press enter to continue...");
                Console.ReadLine();

                Console.Clear();

                Console.WriteLine("You have found a nice spot for the night, there are logs and sticks everywhere so you can make a fire.");
                Console.WriteLine("Press enter to make a fire...");
                Console.ReadLine();
                myCharacter1.MakeFire();
                Console.WriteLine("Press enter to continue...");
                Console.ReadLine();

                Console.Clear();

                Console.WriteLine("You are quite tired, but now that you are warm and have found a place to camp you can rest.");
                Console.WriteLine("Goodnight! Press enter to goto sleep...");
                Console.ReadLine();
                Console.Clear();
                myCharacter1.Sleep();

                Console.WriteLine("Good Morning! Here are your current statistics...");
                myCharacter1.weight = myCharacter1.weight - 3;
                myCharacter1.SimpleAbout();
                Console.WriteLine("Press enter to continue...");
                Console.ReadLine();

                Console.Clear();

                Console.WriteLine("Here are the current stats of the wilderness.");
                myWilderness1.temperature = 64;
                myWilderness1.AboutWilderness();
                Console.WriteLine("\nLooks like you should keep on moving. You can't stay here if you want to escape.");
                Console.WriteLine("Press enter to continue on...");
                Console.ReadLine();

                Console.Clear();
                
                Console.WriteLine("You have been walking for quite a while, you dont seem to know where you are at.");
                myCharacter1.MakeCold();
                myCharacter1.hungerLevel = myCharacter1.hungerLevel - 2;
                myCharacter1.thirstLevel = myCharacter1.thirstLevel - 3;
                myCharacter1.weight = myCharacter1.weight - 3;
                Console.WriteLine("You have a couple of options to make...");
                Console.WriteLine("Press enter to continue...");
                Console.ReadLine();

                Console.Clear();
                running = true;

                while(running == true)
                {
                    string[] answer2Array = new string[5] { "1) Check to find food.", "2) Drink some water.", "3) Check wilderness statistics", "4) Check player statistics.", "5) Continue travelling." };

                    foreach(string answer in answer2Array)
                    {
                        Console.WriteLine(answer);
                    }
                    userMenuInput = Convert.ToInt16(Console.ReadLine());
                    switch(userMenuInput)
                    {
                        case 1:
                            Console.Clear();
                            Console.WriteLine("Unfortunately it seems there is no food around. You don't know how to hunt and there is no where to fish.");
                            Console.WriteLine("Press enter to return...");
                            Console.ReadLine();
                            Console.Clear();
                            break;
                        case 2:
                            Console.Clear();
                            Console.WriteLine("Unfortunately it seems you are unable to find any water.");
                            Console.WriteLine("Press enter to return...");
                            Console.ReadLine();
                            Console.Clear();
                            break;
                        case 3:
                            Console.Clear();
                            myWilderness1.AboutWilderness();
                            Console.WriteLine("Press enter to return...");
                            Console.ReadLine();
                            Console.Clear();
                            break;
                        case 4:
                            Console.Clear();
                            myCharacter1.SimpleAbout();
                            Console.WriteLine("Press enter to return...");
                            Console.ReadLine();
                            Console.Clear();
                            break;
                        case 5:
                            Console.Clear();
                            WildernessPart2();
                            running = false;
                            break;

                    }
                }
                


                




            }

            

            

            


        }
        //wilderness part 2 ----------------------
        public void WildernessPart2()
        {
            //test wilderness part 2 with switch statements from before
            Console.Clear();
            Console.WriteLine("You walked for a very long time.");
            myCharacter1.MakeThirsty();
            myCharacter1.hungerLevel = myCharacter1.hungerLevel - 2;
            myWilderness1.temperature = 68;
            myCharacter1.About();
            myWilderness1.AboutWilderness();
            Console.WriteLine("Press enter to continue...");
            Console.ReadLine();

            Console.Clear();

            Console.WriteLine("Good news, you have spotted lots of things to forage, and also see a fresh water source.");

            running = true;
            bool alreadyAte = false;
            //ADD NUMBER BETWEEN [] 
            string[] answer1Array = new string[4] { "1) Find some food.", "2) Drink Water.", "3) Keep Travelling.", "4) Display Player Stats." };

            while (running == true)
            {
                foreach (string answer in answer1Array)
                {
                    Console.WriteLine(answer);
                }

                

                userMenuInput = Convert.ToInt16(Console.ReadLine());
                switch(userMenuInput)
                {
                    case 1:
                        if(alreadyAte == false)
                        {

                            Console.Clear();
                            Console.WriteLine("You found some more berries, press enter to eat them.");
                            myCharacter1.weight++;
                            myCharacter1.hungerLevel = myCharacter1.hungerLevel + 2;
                            Console.ReadLine();
                            Console.Clear();
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine($"You have ate some berries, your hunger level is now {myCharacter1.hungerLevel}.");
                            alreadyAte = true;
                            Console.ForegroundColor = ConsoleColor.Gray;
                            Console.WriteLine("Press enter to continue...");
                            Console.ReadLine();
                            Console.Clear();
                            break;

                        }
                        else
                        {
                            Console.Clear();
                            Console.WriteLine("You already ate, you should continue on.");
                            Console.WriteLine("Press enter to go back...");
                            Console.ReadLine();
                            Console.Clear();
                            break;

                        }
                        
                    case 2:
                        Console.Clear();
                        Console.WriteLine("You are near a fresh body of water, press enter to drink some water.");
                        myCharacter1.thirstLevel = 10;
                        Console.ReadLine();
                        Console.Clear();
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("You have drank water, your thirst level is now 10");
                        Console.ForegroundColor = ConsoleColor.Gray;
                        Console.WriteLine("Press enter to continue...");
                        Console.ReadLine();
                        Console.Clear();
                        break;
                    case 3:
                        if(myCharacter1.hungerLevel < 2)
                        {
                            Console.Clear();
                            Console.WriteLine("You are quite hungry, perhaps go back and find some food before continuing?");
                            Console.WriteLine("Press enter to return...");
                            Console.ReadLine();
                            Console.Clear();
                            break;

                        }
                        else
                        {
                            Console.Clear();
                            Console.WriteLine("You have decided to continue travelling, keep moving to find a way out!");
                            myCharacter1.weight = myCharacter1.weight - 4;
                            Console.WriteLine("Press enter to continue...");
                            Console.ReadLine();
                            WildernessPart3();
                            running = false;
                            
                            break;
                        }
                    case 4:
                        Console.Clear();
                        myCharacter1.SimpleAbout();
                        Console.WriteLine("Press enter to go back...");
                        Console.ReadLine();
                        Console.Clear();
                        break;




                }


            }




            Console.ReadLine();


        }

        public void WildernessPart3()
        {
            Console.Clear();
            myCharacter1.MakeTired();
            myCharacter1.hungerLevel = myCharacter1.hungerLevel - 1;
            Console.WriteLine("You are very tired, you cannot find food anywhere around you.");
            Console.WriteLine("Although up ahead you do see a lake, and what looks to be an abandoned camp.");
            Console.WriteLine("Press enter to check out the camp...");
            Console.ReadLine();

            Console.Clear();

            Console.WriteLine("You see a small tent with supplies that seem mostly rotted out.");
            Console.WriteLine("Under a small sleeping bag, you see a small fishing pole with some line still attached.");
            Console.WriteLine("You decide to take the fishing pole as it could be useful later.");
            myCharacter1.hasFishingPole = true;
            Console.WriteLine("Press enter to continue...");
            Console.ReadLine();

            Console.Clear();
            myWilderness1.Rain();
            myWilderness1.temperature = 68;
            myCharacter1.hungerLevel = myCharacter1.hungerLevel - 1;
            myCharacter1.MakeCold();
            Console.WriteLine();
            myCharacter1.SimpleAbout();
            Console.WriteLine("Press enter to continue...");
            Console.ReadLine();

            Console.Clear();
            Console.WriteLine("You decided to clean out the tent from the abandoned camp as it is\nthe only source of protection from the rain.");
            Console.WriteLine("Time to go to sleep!");
            Console.WriteLine("Press enter to go to sleep...");
            Console.ReadLine();

            
            fireActive = false;
            Console.Clear();
            myCharacter1.Sleep();
            //myCharacter1.MakeHungry();
            myWilderness1.StopRain();
            myWilderness1.temperature = 75;
            Console.WriteLine("Good morning!");
            Console.WriteLine("Here are your current statistics.");
            myCharacter1.SimpleAbout();
            Console.WriteLine("Press enter to continue...");
            Console.ReadLine();
            
            Console.Clear();
            fireActive = false;
            while (running == true)
            {
                string[] answer3Array = new string[4] { "1) Try and fish.", "2) Make fire.", "3) Keep Travelling.", "4) Display Player Stats." };

                foreach(string answer in answer3Array)
                {
                    Console.WriteLine(answer);
                }

                userMenuInput = Convert.ToInt16(Console.ReadLine());
                switch (userMenuInput)
                {
                    case 1:
                        if(myCharacter1.fishAmount == 0)
                        {
                            Console.Clear();
                            myCharacter1.Fish();
                            Console.WriteLine("Press enter to return...");
                            Console.ReadLine();
                            Console.Clear();
                            break;
                        }
                        else
                        {
                            Console.Clear();
                            Console.WriteLine("You have already caught one, maybe go try and cook it?");
                            Console.WriteLine("Press enter to return...");
                            Console.ReadLine();
                            Console.Clear();
                            break;

                        }
                    case 2:
                        if(myCharacter1.fishAmount == 0)
                        {
                            Console.Clear();
                            Console.WriteLine("Maybe go try and catch some fish to cook before making a fire.");
                            Console.WriteLine("Press enter to return...");
                            Console.ReadLine();
                            Console.Clear();
                            break;
                        }
                        else
                        {
                            if(fireActive == false)
                            {

                                Console.Clear();
                                myCharacter1.MakeFire();
                                Console.WriteLine("Now you can cook your fish! Eat up!");
                                myCharacter1.Eat();
                                myCharacter1.fishAmount = 0;
                                fireActive = true;
                                Console.WriteLine("Press enter to return...");
                                Console.ReadLine();
                                Console.Clear();
                                break;

                            }
                            else
                            {

                                Console.Clear();
                                Console.WriteLine("You already have a fire active.");
                                Console.WriteLine("Press enter to return...");
                                Console.ReadLine();
                                Console.Clear();
                                break;

                            }
                            
                        }
                    case 3:
                        if(myCharacter1.hungerLevel < 3)
                        {
                            Console.Clear();
                            Console.WriteLine("You are too hungry! Eat some food before travelling.");
                            Console.WriteLine("Press enter to return...");
                            Console.ReadLine();
                            Console.Clear();
                            break;
                        }
                        else
                        {
                            Console.Clear();
                            Console.WriteLine("You have ate and now can continue to travel.");
                            //make this the end of the wilderness class to continue on to the next new ones +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                            Console.WriteLine("Press enter to exit the wilderness...");
                            Console.ReadLine();
                            Console.Clear();
                            FlatlandsPart1();
                            running = false;
                            break;
                                
                        }
                    case 4:
                        Console.Clear();
                        myCharacter1.SimpleAbout();
                        Console.WriteLine("Press enter to go back...");
                        Console.ReadLine();
                        Console.Clear();
                        break;




                }

            }

            



               





        }


        //Quarry Option -----------------------------------------------------------------------------------------------------------
        //Create Quarry Class!!!!

        public void QuarryChoice()
        {
            Console.WriteLine("You have chosen the path on the right.");
            Console.WriteLine("Press enter to continue...");
            Console.ReadLine();

            Console.Clear();
            Console.WriteLine("You have been walking for a long time now.");
            myCharacter1.MakeTired();
            myCharacter1.MakeHungry();
            Console.WriteLine("Here are your current player statistics.");
            Console.WriteLine();
            myCharacter1.SimpleAbout();
            Console.WriteLine("\nYou have been walking for quite a while and you now see a giant quarry with a lake in the middle.");
            myQuarry1.temperature = 68;
            myCharacter1.MakeCold();
            Console.WriteLine("Press enter to continue...");
            Console.ReadLine();
            Console.Clear();

            Console.WriteLine("What would you like to do?");
            running = true;
            while (running == true)
            {
                string[] answer5Array = new string[5] { "1) Find food", "2) Set up a fire", "3) View Quarry statistics", "4) View Player Statistics", "5) Try and sleep" };

                foreach (string answer in answer5Array)
                {
                    Console.WriteLine(answer);
                }
                userMenuInput = Convert.ToInt16(Console.ReadLine());
                switch(userMenuInput)
                {
                    case 1:
                        if (myCharacter1.hungerLevel < 5)
                        {
                            Console.Clear();
                            Console.WriteLine("You have found plenty of nuts and berries in the woods, it will get you by for now.");
                            myCharacter1.Eat();
                            Console.WriteLine("Press enter to return...");
                            Console.ReadLine();
                            Console.Clear();
                            break;                            
                        }
                        else
                        {
                            Console.Clear();
                            Console.WriteLine("Looks like you already ate, maybe find somewhere to sleep for the night.");
                            Console.WriteLine("Press enter to return...");
                            Console.ReadLine();
                            Console.Clear();
                            break;
                        }
                    case 2:
                        if  (fireActive == false)
                        {
                            Console.Clear();
                            Console.WriteLine("You are going to need to head back a bit to collect some firewood.");
                            Console.WriteLine("Press enter to go get firewood...");
                            Console.ReadLine();
                            Console.Clear();
                            myCharacter1.weight = myCharacter1.weight - 2;
                            myCharacter1.hungerLevel = myCharacter1.hungerLevel - 1;
                            myCharacter1.thirstLevel = myCharacter1.thirstLevel - 1;

                            Console.WriteLine("Walking has made you a little more thirsty and hungry, but now you have a fire.");
                            fireActive = true;
                            myCharacter1.isCold = false;
                            Console.WriteLine("Maybe you should try to head to sleep?");
                            Console.WriteLine("Press enter to continue...");
                            Console.ReadLine();
                            Console.Clear();
                            break;
                        }
                        else
                        {
                            Console.Clear();
                            Console.WriteLine("You already have a fire.");
                            Console.WriteLine("Press enter to return...");
                            Console.ReadLine();
                            Console.Clear();
                            break;
                        }
                    case 3:
                        Console.Clear();
                        myQuarry1.AboutQuarry();
                        Console.WriteLine("Press enter to return...");
                        Console.ReadLine();
                        Console.Clear();
                        break;
                    case 4:
                        Console.Clear();
                        myCharacter1.SimpleAbout();
                        Console.WriteLine("Press enter to go back...");
                        Console.ReadLine();
                        Console.Clear();
                        break;
                    case 5:
                        if (fireActive == false)
                        {
                            Console.Clear();
                            Console.WriteLine("Maybe try and make a fire before going to sleep?");
                            Console.WriteLine("Press enter to return...");
                            Console.ReadLine();
                            Console.Clear();
                            break;
                                
                        }
                        else
                        {
                            Console.Clear();
                            Console.WriteLine("Time to go to sleep! Get some rest for tomorrow!");
                            Console.WriteLine("Press enter to go to sleep...");
                            Console.ReadLine();

                            Console.Clear();
                            running = false;
                            QuarryPart2();
                            break;
                        }



                }

            }
            




            

        }

        public void QuarryPart2()
        {
            fireActive = false;

            Console.Clear();
            myCharacter1.Sleep();
            myQuarry1.temperature = 75;
            Console.WriteLine("Good morning! Here are your current player statistics.");
            Console.WriteLine();
            myCharacter1.SimpleAbout();
            Console.WriteLine("\nYou have a two options, press 1 to walk far around the quarry, to put more distance behind you.");
            Console.WriteLine("Or, press 2 so you can stay where you are.");


            userMenuInput = Convert.ToInt16(Console.ReadLine());
            if (userMenuInput == 1)
            {
                Console.Clear();
                Console.WriteLine("You have decided to walk around the quarry. It looks like its going to be a long trip.");
                Console.WriteLine();
                myCharacter1.MakeHungry();
                myCharacter1.weight = myCharacter1.weight - 3;
                Console.WriteLine();
                myCharacter1.MakeThirsty();
                Console.WriteLine();
                Console.WriteLine("It looks like you have no choice but to keep moving. You can't seem to find food or water until you make it back down.");
                Console.WriteLine("Press enter to continue...");
                Console.ReadLine();
                Console.Clear();

                myQuarry1.Rain();
                Console.WriteLine();
                Console.WriteLine("You are starting to get cold from the rain. Watch out! The rocks are starting to become slippery.");
                Console.WriteLine("Press enter to continue...");
                Console.ReadLine();
                Console.Clear();
                myQuarry1.Rockslide();
                Console.WriteLine("Press enter to continue...");
                Console.ReadLine();
                Console.Clear();
                Console.WriteLine("You jumped off of the ledge and managed to land in the quarry, fortunatly\nyou don't seem to be injured but you lost all your progress.");
                Console.WriteLine("You have no choice but to make camp for the night down at the quarry. You are frustrated as you seem to still be stuck.");
                Console.WriteLine();
                myCharacter1.MakeTired();
                Console.WriteLine();
                Console.WriteLine("Press enter to continue...");
                Console.ReadLine();
                Console.Clear();

                Console.WriteLine("You are exhausted, you decide you have no choice but to force yourself to sleep in the cold under some trees.");
                Console.WriteLine("Making a fire is no good, your going to have to wait out the rain.");
                Console.WriteLine("Press enter to goto sleep...");
                Console.ReadLine();
                Console.Clear();
                QuarryPart3();








            }
            if (userMenuInput == 2)
            {
                Console.Clear();
                Console.WriteLine("You have decided to make camp here now, you don't know your surroundings and think its best to stay put for now.");
                Console.WriteLine("Select an option to continue your adventure.");
                string[] answer6Array = new string[3] { "1) View your current statistics", "2) View quarry statistics", "3) Go search for firewood" };

                //userMenuInput = Convert.ToInt16(Console.ReadLine());
                running = true;

                while(running == true)
                {
                    foreach (string answer in answer6Array)
                    {
                        Console.WriteLine(answer);
                    }
                    userMenuInput = Convert.ToInt16(Console.ReadLine());
                    switch (userMenuInput)
                    {
                        case 1:
                            Console.Clear();
                            myCharacter1.SimpleAbout();
                            Console.WriteLine("Press enter to go back...");
                            Console.ReadLine();
                            Console.Clear();
                            break;
                        case 2:
                            Console.Clear();
                            myQuarry1.AboutQuarry();
                            Console.WriteLine("Press enter to return...");
                            Console.ReadLine();
                            Console.Clear();
                            break;
                        case 3:
                            Console.Clear();
                            Console.WriteLine("You decided to search for firewood.");
                            myCharacter1.weight = myCharacter1.weight - 3;
                            //Console.WriteLine();
                            myCharacter1.hungerLevel = myCharacter1.hungerLevel - 1;
                            Console.WriteLine();
                            myCharacter1.MakeTired();
                            Console.WriteLine();
                            Console.WriteLine("It took you a while to find some dry firewood, but now you made it back to camp.");
                            Console.WriteLine("Time to create a fire!");
                            Console.WriteLine("Press enter to make a fire...");
                            Console.ReadLine();
                            Console.Clear();
                            Console.WriteLine("You have created a fire! Maybe its time to get some rest, you need to find a way back home!");
                            Console.WriteLine("Press enter to continue...");
                            Console.ReadLine();
                            Console.Clear();
                            QuarryPart3();
                            running = false;
                            break;






                     }


                }


                

            }

            


        }


        public void QuarryPart3()
        {
            if(myQuarry1.isRaining == true)
            {
                
                myQuarry1.isRaining = false;
                Console.WriteLine("It is no longer raining.");
            }
            Console.Clear();
            myCharacter1.Sleep();
            Console.WriteLine();
            Console.WriteLine("You are now awake. Here are you current statistics. Followed by the Quarrys statistics.");
            Console.WriteLine();
            myCharacter1.SimpleAbout();
            Console.WriteLine();
            myQuarry1.AboutQuarry();
            Console.WriteLine("Press enter to continue...");
            Console.ReadLine();
            Console.Clear();

            Console.WriteLine("You decide you need to start making some food. You think you will be able to try and spearfish, but you need to create one.");
            Console.WriteLine("You set off back into the woods to look for materials, and to sharpen up a rock to use.");
            Console.WriteLine("Press enter to continue...");
            Console.ReadLine();
            Console.Clear();

            Console.WriteLine("You find a sharp rock to use for the spear, and now all you need is a good stick.");
            myCharacter1.hungerLevel = myCharacter1.hungerLevel - 2;
            myCharacter1.thirstLevel = myCharacter1.thirstLevel - 3;
            myCharacter1.weight = myCharacter1.weight - 3;
            Console.WriteLine();
            Console.WriteLine("You are getting hungry, and in good time because you have put together the spear. Time to try it out!");
            myCharacter1.hasSpearFish = true;
            Console.WriteLine("Time to head back to camp.");
            Console.WriteLine("Press enter to return...");
            Console.ReadLine();
            Console.Clear();

            Console.WriteLine("You have made it back to camp. Why not try out the spear and see if it works?");
            Console.WriteLine("After many unsuccessful attempts, you managed to catch a fish. But not quite a big one.");
            myCharacter1.fishAmount = 1;
            Console.WriteLine("Press enter to continue...");
            Console.ReadLine();
            Console.Clear();

            Console.WriteLine("Looks like you will need to make a fire first.");
            Console.WriteLine("While you are here maybe drink some water before looking for firewood.");
            Console.WriteLine("Press enter to drink...");
            Console.ReadLine();
            myCharacter1.Drink();
            Console.WriteLine();
            Console.WriteLine("Time to go look for firewood.");
            Console.WriteLine("Press enter to go look for firewood...");
            Console.ReadLine();
            Console.Clear();

            myCharacter1.weight = myCharacter1.weight - 2;
            Console.WriteLine("You have found some firewood, time to go cook that delicious fish!");
            Console.WriteLine("After a while you made it back to camp.");
            myQuarry1.temperature = 64;
            Console.WriteLine("Press enter to cook...");
            Console.ReadLine();
            Console.Clear();

            Console.WriteLine("You have cooked the fish. Maybe now you should continue on your journey, you cant stay here forever!");
            myCharacter1.hungerLevel = myCharacter1.hungerLevel + 4;
            Console.WriteLine("Press enter to continue...");
            Console.ReadLine();
            Console.Clear();

            running = true;
            while(running == true)
            {
                string[] answer7Array = new string[3] {"1) Check your player statistics", "2) Check the quarry statistics", "3) Leave the quarry" };
                foreach(string answer7 in answer7Array)
                {
                    Console.WriteLine(answer7);
                }
                userMenuInput = Convert.ToInt16(Console.ReadLine());
                switch (userMenuInput)
                {
                    case 1:
                        Console.Clear();
                        myCharacter1.SimpleAbout();
                        Console.WriteLine("Press enter to go back...");
                        Console.ReadLine();
                        Console.Clear();
                        break;
                    case 2:
                        Console.Clear();
                        myQuarry1.AboutQuarry();
                        Console.WriteLine("Press enter to return...");
                        Console.ReadLine();
                        Console.Clear();
                        break;
                    case 3:                     
                        Console.Clear();
                        Console.WriteLine("You again have two natural paths that lay before you, you decide to choose one.");
                        Console.WriteLine("There are two paths before you");
                        if(myCharacter1.hungerLevel < 5)
                        {
                            FlatlandsPart1();
                            running = false;
                            break;
                        }
                        if(myCharacter1.hungerLevel > 6)
                        {
                            FlatlandsPart2();
                            running = false;
                            break;
                        }
                        break;
                        
                        
                        
                        
                        






                }
            }




        }

        public void FlatlandsPart1()
        {
            Console.WriteLine("Because you were hungry, the the path on the left looked promising and not very long.");
            Flatlands myFlatlands1 = new Flatlands(78, "Flatlands");
            myFlatlands1.AboutBiome();
            myCharacter1.MakeHungry();
            myCharacter1.MakeThirsty();
            Console.WriteLine("Press enter to continue...");
            Console.ReadLine();
            Console.Clear();



            Console.WriteLine("You take a good look around you. You don't see anything from before behind you. And you seem to be in a new place.");
            myFlatlands1.AboutFlatLands();
            Console.WriteLine("Press enter to continue...");
            Console.ReadLine();
            Console.Clear();

            string[] answer8Array = new string[3] { "1) Keep travelling", "2) Check player statistics", "3) Check Flatlands statistics" };

            while (running == true)
            {
                foreach(string answer in answer8Array)
                {
                    Console.WriteLine(answer);
                }
                userMenuInput = Convert.ToInt16(Console.ReadLine());

                switch(userMenuInput)
                {
                    case 1:
                        Console.Clear();
                        Console.WriteLine("You have decided to keep travelling.");
                        Console.WriteLine("Press enter to continue...");
                        Console.ReadLine();
                        Console.Clear();
                        running = false;
                        break;
                    case 2:
                        Console.Clear();
                        myCharacter1.SimpleAbout();
                        Console.WriteLine("Press enter to go back...");
                        Console.ReadLine();
                        Console.Clear();
                        break;
                    case 3:
                        Console.Clear();
                        myFlatlands1.AboutBiome();
                        Console.WriteLine("Press enter to return...");
                        Console.ReadLine();
                        Console.Clear();
                        break;
                   







                }

            }
            Console.WriteLine("While out searching, you start to notice the swift change in weather.");
            myFlatlands1.Wind();
            myFlatlands1.DecreaseTemp();
            Console.WriteLine();
            myCharacter1.MakeCold();
            Console.WriteLine("You decide to keep moving on and hopefully find shelter.");
            Console.WriteLine("Press enter to continue...");
            Console.ReadLine();
            Console.Clear();

            Console.WriteLine("While walking you notice a small incline into the dirt, what seems to be an entrance to a cave.");
            myCharacter1.MakeTired();
            Console.WriteLine();
            Console.WriteLine("Upon further inspection you notice an area to make shelter for the night.");
            running = true;

            string[] answer9Array = new string[3] { "1) Attempt to make fire", "2) Go to sleep", "3) Check player statistics" };
            while (running == true)
            {
                foreach (string answer in answer9Array)
                {
                    Console.WriteLine(answer);
                }
                userMenuInput = Convert.ToInt16(Console.ReadLine());

                switch(userMenuInput)
                {
                    case 1:
                        Console.Clear();
                        Console.WriteLine("Attempt unsuccessful.");
                        Console.WriteLine("Press enter to return");
                        Console.ReadLine();
                        Console.Clear();
                        break;
                    case 2:
                        Console.Clear();
                        running = false;
                        break;
                    case 3:
                        Console.Clear();
                        myCharacter1.SimpleAbout();
                        Console.WriteLine("Press enter to go back...");
                        Console.ReadLine();
                        Console.Clear();
                        break;

                }

            }

            myCharacter1.Sleep();
            Console.WriteLine("Good morning, here are your current statistics.");
            Console.WriteLine();
            myCharacter1.SimpleAbout();
            Console.WriteLine("Press enter to continue...");
            Console.ReadLine();
            Console.Clear();

            Console.WriteLine("You have travelled quite a long way, but you notice what seems to be a small dirt road.");
            Console.WriteLine("The road looks wide enough to fit a car, so you decide to head north.");
            Console.WriteLine("Press enter to continue...");
            Console.ReadLine();
            Console.Clear();

            Console.WriteLine("You are quite hungry and thirsty, you walk off straight east to look for water.");
            Console.WriteLine("After a long time walking, you find a small river.");
            Console.WriteLine("You decide to go fishing.");
            if(myCharacter1.hasFishingPole == true)
            {
                Console.WriteLine("You attempt to use your fishing pole.");
                Console.WriteLine("After many attempts you manage to snag a big fish.");

            }
            if(myCharacter1.hasSpearFish == true)
            {
                Console.WriteLine("You attempt to use your spear fish.");
                Console.WriteLine("After many attempts you manage to snag a small fish.");

            }
            
            Console.WriteLine("You need to create a fire in order to cook the fish, so you walk past some trees between the\nriver and the road.");
            Console.WriteLine();
            myCharacter1.MakeTired();
            Console.WriteLine("Press enter to continue...");
            Console.ReadLine();
            Console.Clear();

            Console.WriteLine("You made it to the trees, time to make a fire for that fish.");
            Console.WriteLine("Press enter to make a fire...");
            Console.ReadLine();
            myCharacter1.MakeFire();
            Console.WriteLine("Time to make a meal.");
            Console.WriteLine("Press enter to continue...");
            Console.ReadLine();
            Console.Clear();
            if (myCharacter1.hasFishingPole == true)
            {
                myCharacter1.hungerLevel = myCharacter1.hungerLevel + 8;
                Console.WriteLine("You ate a big meal. Time to go back to the road.");
            }
            if (myCharacter1.hasSpearFish == true)
            {
                myCharacter1.hungerLevel = myCharacter1.hungerLevel + 5;
                Console.WriteLine("You ate a good meal. Time to go back to the road.");

            }
            Console.WriteLine("Press enter to continue your journey...");
            Console.ReadLine();
            Console.Clear();

            Console.WriteLine("You made it back to the road. Here are your current statistics.");
            Console.WriteLine();
            myCharacter1.SimpleAbout();
            Console.WriteLine();
            Console.WriteLine("You are quite tired. But you decide that this road is your last chance.");
            Console.WriteLine("After walking for a long time you see something amazing. A four way intersection, with street signs!");
            Console.WriteLine("Press enter to continue...");
            Console.ReadLine();
            Console.Clear();

            Console.WriteLine("You decide at this point that you can hitchhike. You continue to walk for a very long time.");
            myCharacter1.weight = myCharacter1.weight - 4;
            Console.WriteLine("Press enter to continue...");
            Console.ReadLine();
            Console.Clear();

            Console.WriteLine("You walk for hours, but finally see a car pass by and they pick you up...");
            Ending();
            










        }

        public void FlatlandsPart2()
        {
            Console.WriteLine("Becuase you were not that hungry, you felt the path on the right was the good choice.");
            Flatlands myFlatlands2 = new Flatlands(70, "Flatlands");
            myFlatlands2.AboutBiome();
            Console.WriteLine("Press enter to continue...");
            Console.ReadLine();
            Console.Clear();

            Console.WriteLine("You take a look around you, and notice you see nothing around you but flat land.");
            myFlatlands2.AboutFlatLands();
            Console.WriteLine("Press enter to continue...");
            Console.ReadLine();
            Console.Clear();

            myFlatlands2.Thunderstorm();

            running = true;
            string[] answer10Array = new string[4] { "1) Check player statistics", "2) Check Flatlands statistics", "3) Travel north", "4) Stay where you are for now " };
            while(running == true)
            {
                Console.WriteLine("You have a few options...");
                foreach(string answer in answer10Array)
                {
                    Console.WriteLine(answer);
                }
                userMenuInput = Convert.ToInt16(Console.ReadLine());
                switch(userMenuInput)
                {
                    case 1:
                        Console.Clear();
                        myCharacter1.SimpleAbout();
                        Console.WriteLine("Press enter to go back...");
                        Console.ReadLine();
                        Console.Clear();
                        break;
                    case 2:
                        Console.Clear();
                        myFlatlands2.AboutBiome();
                        Console.WriteLine("Press enter to return...");
                        Console.ReadLine();
                        Console.Clear();
                        break;
                    case 3:
                        Console.Clear();
                        Console.WriteLine("You decide to travel north.");
                        myCharacter1.weight = myCharacter1.weight - 2;
                        
                        running = false;
                        break;
                    case 4:
                        Console.Clear();
                        Console.WriteLine("Because of the thunderstorm, and there being no where to cover yourself from rain\nyou should probably keep moving.");
                        Console.WriteLine("Press enter to return...");
                        Console.ReadLine();
                        Console.Clear();
                        break;








                }



            }

            Console.Clear();
            Console.WriteLine("The thunderstorm is very strong.");
            myCharacter1.MakeCold();
            Console.WriteLine();
            Console.WriteLine("You have two choices, try and find a small cave to sleep out the storm, or continue to travel in hopes\nto find a way out. Select an option.");
            Console.WriteLine("1) Find a cave");
            Console.WriteLine("2) Keep moving");
            userMenuInput = Convert.ToInt16(Console.ReadLine());

            if (userMenuInput == 1)
            {
                //rescued and hurt leg option...
                Console.Clear();
                Console.WriteLine("You decide to look for a cave.");
                myCharacter1.MakeTired();
                myCharacter1.hungerLevel = myCharacter1.hungerLevel - 1;
                myCharacter1.MakeThirsty();
                Console.WriteLine("Press enter to continue...");
                Console.ReadLine();
                Console.Clear();

                Console.WriteLine("While looking for a cave, you stumble across a rock stuck in the dirt.");
                Console.WriteLine("You seem to have injured your leg and cant move. Luckily you were lucky enough to find a cave.");
                Console.WriteLine("Press enter to continue...");
                Console.ReadLine();
                Console.Clear();

                Console.WriteLine("You decide because of your leg you are going to go right to sleep.");
                Console.WriteLine("With little options left you hope that you are near civilization.");
                Console.WriteLine("Press enter to go to sleep...");
                Console.ReadLine();
                Console.Clear();
                myCharacter1.Sleep();
                Console.WriteLine("You use some sticks and tie it to your leg to keep it straight.");
                myCharacter1.thirstLevel = 2;
                Console.WriteLine("After going outside you start walking, and the pain in your leg is too much.");
                Console.WriteLine("Eventually you collapse and pass out.");
                Console.WriteLine("Pres enter to continue...");

                Console.ReadLine();
                Console.Clear();

                Console.WriteLine("You wake up and find that you are in a hospital bed. You don't know how but you were\nlucky enough to be rescued.");
                Console.WriteLine("The doctors explain you were found by a family driving while walking across the road.\nYou don't even remember.");
                Console.WriteLine("Press enter to continue...");

                Ending();

            }
            if (userMenuInput == 2)
            {
                //good choice easy exit option
                Console.WriteLine("You decided to keep moving.");
                myCharacter1.hungerLevel = 1;
                myCharacter1.weight = myCharacter1.weight - 6;
                Console.WriteLine("You are very hungry, luckily you spotted a road up ahead.");
                Console.WriteLine("You decide to keep walking the road.");
                Console.WriteLine("Press enter to continue...");
                Console.ReadLine();
                Console.Clear();

                Console.WriteLine("While walking you come across something in the distance, it looks like town.");
                Console.WriteLine("Your excitement gets the better of you as you start running to what looks like your rescue.");
                Console.WriteLine("Press enter to continue...");
                Console.ReadLine();
                Console.Clear();

                Console.WriteLine("You make it to a gas station and tell them your sitation.\nThey give you food and water and call for help.");
                myCharacter1.Eat();
                Console.WriteLine();
                myCharacter1.Drink();
                Console.WriteLine("Press enter to continue...");

                Ending();
            }










        }

        public void FlatlandsPart3()
        {
            //Console.Clear();
            //Console.WriteLine("The thunderstorm is very strong.");
            //myCharacter1.MakeCold();
            //Console.WriteLine();
            //Console.WriteLine("You have two choices, try and find a small cave to sleep out the storm, or continue to travel in hopes\nto find a way out. Select an option.");
            //Console.WriteLine("1) Find a cave");
            //Console.WriteLine("2) Keep moving");
            //userMenuInput = Convert.ToInt16(Console.ReadLine());

            //if (userMenuInput == 1)
            //{
            //    //rescued and hurt leg option...
            //    Console.Clear();
            //    Console.WriteLine("You decide to look for a cave.");
            //    myCharacter1.MakeTired();
            //    myCharacter1.hungerLevel = myCharacter1.hungerLevel - 1;
            //    myCharacter1.MakeThirsty();
            //    Console.WriteLine("Press enter to continue...");
            //    Console.ReadLine();
            //    Console.Clear();

            //    Console.WriteLine("While looking for a cave, you stumble across a rock stuck in the dirt.");
            //    Console.WriteLine("You seem to have injured your leg and cant move. Luckily you were lucky enough to find a cave.");
            //    Console.WriteLine("Press enter to continue...");
            //    Console.ReadLine();
            //    Console.Clear();

            //    Console.WriteLine("You decide because of your leg you are going to go right to sleep.");
            //    Console.WriteLine("With little options left you hope that you are near civilization.");
            //    Console.WriteLine("Press enter to go to sleep...");
            //    Console.ReadLine();
                
            //    Console.Clear();

                
            //    myCharacter1.Sleep();

            //    Ending();

            //}
            //if (userMenuInput == 2)
            //{
            //    Console.WriteLine("You decided to keep moving.");
            //    myCharacter1.hungerLevel = 1;
            //    myCharacter1.weight = myCharacter1.weight - 6;
            //    Console.WriteLine("You are very hungry, luckily you spotted a road up ahead.");
            //    Console.WriteLine("You decide to keep walking the road.");
            //    Console.WriteLine("Press enter to continue...");
            //    Console.ReadLine();
            //    Console.Clear();

            //    Ending();
            //}
            

        }

        public void Ending()
        {
            Console.WriteLine("Congratulations! You have beat the survival game.");
            myCharacter1.EndingStats();
            Console.WriteLine("You made some pretty interesting choices... maybe try playing the game again!");
            Console.WriteLine("Press enter to exit game...");
            Console.ReadLine();
            Environment.Exit(10);

        }
    }
}
