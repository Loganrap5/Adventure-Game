﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace MidtermAdventureGame
{
    public class Wilderness
    {
        public int temperature;

        bool isRaining;
        bool isWindy;
        bool isThunderstorming;

        //constructer
        public Wilderness()
        {
            this.temperature = 75;

            this.isRaining = false;
            this.isWindy = false;
            this.isThunderstorming = false;

        }

        //-------------------------------------------
        //this is a forest class with minimal access to water but more things to scavenge and more access to firewood
        //-------------------------------------------

        //methods
        
        //about method to show current temperature and if its raining or not
        public void AboutWilderness()
        {
            Console.ForegroundColor = ConsoleColor.Green;
            if (isRaining == true)
            {
                Console.WriteLine($"It is {temperature} degrees. And it is raining.");

            }
           
            if(isThunderstorming == true)
            {
                Console.WriteLine($"It is {temperature} degrees. It is now thunderstorming outside!");


            }
           
            else if (temperature < 70)
            {
                Console.WriteLine($"It is {temperature} degrees. Its slightly chilly!");


            }
           
            else if (temperature > 71)
            {
                Console.WriteLine($"It is {temperature} degrees. Its a comfortable temperature outside.");



            }
            Console.ForegroundColor = ConsoleColor.Gray;
           
            

        }
        
        
        
        
        public void Rain()
        {
            isRaining = true;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("It is now raining.");
            Console.ForegroundColor = ConsoleColor.Gray;



        }

        public void StopRain()
        {
            isRaining = false;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("It is no longer raining.");
            Console.ForegroundColor = ConsoleColor.Gray;
        }

        public void Wind()
        {
            isWindy = true;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("It is now windy out.");
            Console.ForegroundColor = ConsoleColor.Gray;

        }

        public void Thunderstorm()
        {
            isThunderstorming = true;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("It is now thunderstorming, maybe find some shelter?");
            Console.ForegroundColor = ConsoleColor.Gray;




        }
        //method for increasing temperature
        public void IncreseTemp()
        {
            temperature = temperature + 10;

        }

        //method for decreasing temperature
        public void DecreaseTemp()
        {
            temperature = temperature - 10;

        }



    }
}
