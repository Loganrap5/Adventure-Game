﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Security;
using System.Text;
using System.Threading.Tasks;

namespace MidtermAdventureGame
{
    public class Character
    {

        //vars go here ------------------------------------------------------

        private string name;
        
        public int hungerLevel;
        public int thirstLevel;
        public int weight;
        
        public bool isCold;
        public bool isTired;

        public int fishAmount;

        public bool hasFishingPole;
        public bool hasSpearFish;
        



        //constructer goes here ---------------------------------------------

        public Character()
        {

            //base variables for character class below
            this.name = "UserName";
            this.hungerLevel = 5;
            this.thirstLevel = 5;
            this.weight = 180;
            this.isCold = false;
            this.isTired = false;
            this.hasFishingPole = false;
            this.hasSpearFish = false;

        }

        //methods go here ----------------------------------------------------


        //create name method
        public void CreateName()
        {
            Console.WriteLine("What is your name?");
            name = Console.ReadLine();
            Console.WriteLine("Press enter to continue...");
            Console.ReadLine();
            Console.Clear();

        }



        //About Method displays players current stats
        public void About()
        {

            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine($"Hello {name}! Currently, you weigh {weight} lbs. Right now your hunger level is {hungerLevel}. And your thirst level is {thirstLevel}. ");
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine("Press enter to continue...");
            Console.ReadLine();
            Console.Clear();

        }

        //simple about method to display current stats
        public void SimpleAbout()
        {

            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine($"Current weight: {weight} lbs.");
            if (isTired == true)
            {
                Console.WriteLine("You are currently tired.");
            }
            else if(isTired == false)
            {
                Console.WriteLine("You are not tired.");
            }
            if (isCold == true)
            {
                Console.WriteLine("You are cold.");
            }
            else if (isCold == false)
            {
                Console.WriteLine("You are warm.");
            }
            Console.WriteLine($"Thirst level: {thirstLevel}");
            Console.WriteLine($"Hunger level: {hungerLevel}");
            Console.ForegroundColor = ConsoleColor.Gray;
            


        }

        //Eat Method adds 5 hunger level points
        public void Eat()
        {

            hungerLevel = hungerLevel + 5;
            weight = weight + 1;
            Console.WriteLine("You are now full.");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine($"Your hunger level is now {hungerLevel}.");
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.ReadLine();

        }

        //Drink Method
        public void Drink()
        {
            thirstLevel = thirstLevel + 5;
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("You are no longer thirsty.");
            Console.WriteLine($"Your thirst level is now {thirstLevel}.");
            Console.ForegroundColor = ConsoleColor.Gray;


            


        }

        //Sleep Method

        public void Sleep()
        {

            isTired = false;
            Console.WriteLine("You just woke up.");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("You are no longer tired.");
            Console.ForegroundColor = ConsoleColor.Gray;


        }

        //create fire method
        public void MakeFire()
        {
            isCold = false;
            Console.WriteLine("You have made a fire.");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("You are no longer cold.");
            Console.ForegroundColor = ConsoleColor.Gray;



        }

        //scavenge food method 
        public void Scavenge()
        {
            hungerLevel = hungerLevel + 3;
            weight = weight + 1;
            Console.WriteLine("You ate a small meal.");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine($"Your hunger level is now {hungerLevel}.");
            Console.ForegroundColor = ConsoleColor.Gray;
            
            

        }

        public void Fish()
        {
            fishAmount = fishAmount + 1;
            weight = weight - 1;
            Console.WriteLine("You caught a fish.");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine($"You currently have {fishAmount} fish in your inventory.");
            Console.ForegroundColor = ConsoleColor.Gray;

        }

        //add method to change character statistics and show it in console
        public void MakeCold()
        {
            isCold = true;
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("You are now cold.");
            Console.ForegroundColor = ConsoleColor.Gray;

        }

        public void MakeTired()
        {
            isTired = true;
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("You are now tired.");
            Console.ForegroundColor = ConsoleColor.Gray;

        }

        public void MakeHungry()
        {
            hungerLevel = 2;
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("You are getting hungry, maybe find some food soon.");
            Console.WriteLine($"Hunger Level = {hungerLevel}.");
            Console.ForegroundColor = ConsoleColor.Gray;

        }

        public void MakeThirsty()
        {
            thirstLevel = 2;
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("You are getting thirsty, maybe find some water soon.");
            Console.WriteLine($"Thirst Level = {thirstLevel}.");
            Console.ForegroundColor = ConsoleColor.Gray;

        }

        public void EndingStats()
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine($"Player name: {name}");
            Console.WriteLine($"Player weight: {weight}");
            Console.WriteLine($"Player ending hunger level {hungerLevel}");
            Console.WriteLine($"Player ending thirst level {thirstLevel}");
            Console.ForegroundColor = ConsoleColor.Gray;
            

        }
        


    }
}
