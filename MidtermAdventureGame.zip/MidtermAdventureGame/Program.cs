﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MidtermAdventureGame
{
    public class Program
    {
        static void Main()
        {

            
            Wilderness myWilderness1 = new Wilderness();
            Quarry myQuarry1 = new Quarry();
            Game myGame1 = new Game();
            


            myGame1.Menu();

            

            
            myGame1.Intro();




            










            

        }
    }
}
